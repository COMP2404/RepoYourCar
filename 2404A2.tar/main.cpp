#include "main.h"
//`pkg-config gtkmm-3.0 --cflags --libs`

using namespace std;
char buf[5];

int main(int argc, char** argv) {

	/////////////////////////////////////////////////////
	//-----------Declaration of all the widgets------////
	/////////////////////////////////////////////////////
	
	WindowApp *theApp = new WindowApp();
	Control utility;
	utility.createWindow(argc, argv);
	

	gtk_main();

	return 0;
}
