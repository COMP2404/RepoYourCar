======READ ME========
(Read-Only)
=====================
-program graphics built on GTKmm library
-packaged using `pkg-config gtkmm-3.0 --cflags --libs`
-compile using Makefile's "make" command
-to run the executable:./cuTaes
or  "make run" command in shell				
*
*
*
*
*
*
*
</readme>
